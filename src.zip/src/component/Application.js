import React from "react";

function Application() {
  return <div>Application</div>;
}

export default Application;

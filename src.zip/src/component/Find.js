import React from "react";

function Find() {
  return <div>Find</div>;
}

export default Find;

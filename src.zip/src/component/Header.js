import React from "react";

function Header() {
  return <div style={{ height: "7%" }}>Header</div>;
}

export default Header;

import Message from "../component/Message";

function Mainbar() {
  return (
    <div
      style={{
        width: "100%",
        height: "100%",
      }}
    >
      <Message />
    </div>
  );
}

export default Mainbar;

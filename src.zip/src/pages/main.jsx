import React from "react";
import Dashboard from "./dashboard";
// import { useLocation } from "react-router-dom";
// function Protected() {
//   // let location = useLocation();
//   // let access;
//   // access = location.state?.access;
//   return <Dashboard />;
// }

function Main() {
  return <Dashboard />;
}

export default Main;
